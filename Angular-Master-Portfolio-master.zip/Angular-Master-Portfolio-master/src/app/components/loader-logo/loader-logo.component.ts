import { Component } from '@angular/core';

@Component({
  selector: 'app-loader-logo',
  standalone: true,
  imports: [],
  templateUrl: './loader-logo.component.html',
  styleUrl: './loader-logo.component.scss'
})
export class LoaderLogoComponent {

}
