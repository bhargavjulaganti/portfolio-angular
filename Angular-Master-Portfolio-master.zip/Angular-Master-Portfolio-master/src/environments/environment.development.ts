export const environment = {
    APP_URL: "https://angular-master-portfolio.web.app",
    API_URL: "https://common-server-9df8.onrender.com/",
    RE_CAPTCHA_V3: "6LedUxcqAAAAAKsctlowzDQtHbN43D1y7s8eAyL8",
};
